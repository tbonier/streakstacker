// JS is inlined in index.html for simplicity
